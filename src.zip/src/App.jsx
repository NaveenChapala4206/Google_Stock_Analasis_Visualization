// src/App.jsx
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import { useState, useEffect } from "react";
import Sidebar from "./components/SideBar";
import LoginPage from "./components/LoginPage";
import RegisterPage from "./components/RegisterPage";
import LogoutPage from "./components/LogoutPage";
//import StudentCRUD_PHP from "./components/StudentCRUD_PHP";
import StudentCRUD from "./components/StudentCRUD";


function Layout({ children }) {
  return (
    <div style={{ display: "flex" }}>
      <Sidebar />
      <div style={{ marginLeft: "20px", padding: "20px" }}>{children}</div>
    </div>
  );
}

function App() {

  const [isAuthenticated, setIsAuthenticated] = useState(!!localStorage.getItem("user"));

  return (
    <Router>
      <Routes>
        <Route path="/" element={<Navigate to="/login" />} />
        <Route
          path="/login"
          element={<LoginPage setIsAuthenticated={setIsAuthenticated} />}
        />
        <Route path="/register" element={<RegisterPage setIsAuthenticated={setIsAuthenticated} />} />
        <Route path="/logout" element={<LogoutPage />} />
        <Route path="/student"  element={ 
          isAuthenticated ? (
              <Layout>
                <StudentCRUD />
                
              </Layout>
            ) : (
              <Navigate to="/login" />
            )
          }
        />
      </Routes>
    </Router>
  );
}

export default App;
