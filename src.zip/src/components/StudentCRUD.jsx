import React, { useState, useEffect } from "react";
import StudentTable from "./StudentTable";
import {
  TextField,
  Button,
  Box,
  Typography,
  Container,
  Alert,
} from "@mui/material";
import axios from "axios";

const StudentCRUD = () => {
  const [form, setForm] = useState({
    name: "",
    email: "",
    age: "",
    course: "",
  });

  const [students, setStudents] = useState([]);
  const [editingId, setEditingId] = useState(null);

  const [errors, setErrors] = useState({});
  const [successMessage, setSuccessMessage] = useState("");
  const [serverError, setServerError] = useState("");
  const [showForm, setShowForm] = useState(false);  

  // Fetch all students
  const fetchStudents = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/students");
      setStudents(res.data);
    } catch (err) {
      console.error(err);
      setServerError("Failed to fetch students");
    }
  };

  useEffect(() => {
    fetchStudents();
  }, []);

  const validate = () => {
    let formerrors = {};
    formerrors.name = form.name ? "" : "Name is required";
    formerrors.email = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)
      ? ""
      : "Valid email is required";
    formerrors.age = /^\d+$/.test(form.age) ? "" : "Numeric age is required";
    formerrors.course = form.course ? "" : "Course is required";
    setErrors(formerrors);
    return Object.values(formerrors).every((x) => x === "");
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: "" });
    setServerError("");
    setSuccessMessage("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    try {
      if (editingId) {
        const res = await axios.put(
          `http://localhost:5000/api/students/${editingId}`,
          form
        );
        setSuccessMessage(res.data.message || "Updated successfully");
      } else {
        const res = await axios.post(
          "http://localhost:5000/api/students",
          form
        );
        setSuccessMessage(
          res.data.message || "Student registered successfully"
        );
      }

      setForm({ name: "", email: "", age: "", course: "" });
      setEditingId(null);
      fetchStudents();
      setShowForm(false);
    } catch (err) {
      console.error(err);
      setServerError(err.response?.data?.message || "Failed to save student");
    }
  };

  const handleEdit = (student) => {
    setForm(student);
    setEditingId(student._id || student.id);
    setSuccessMessage("");
    setServerError("");
    setShowForm(true);
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this student?"))
      return;
    try {
      const res = await axios.delete(
        `http://localhost:5000/api/students/${id}`
      );
      setSuccessMessage(res.data.message || "Deleted successfully");
      fetchStudents();
    } catch (err) {
      console.error(err);
      setServerError("Failed to delete student");
    }
  };

  const handleAddNew = () => {
    setForm({ name: "", email: "", age: "", course: "" });
    setEditingId(null);
    setShowForm(true);
    setErrors({});
    setSuccessMessage("");
    setServerError("");
  };

  return (
    <Container maxWidth="md">
      <Box mt={5}>
        <Typography variant="h5" gutterBottom>
          Student Management using  ExpressJS and MongoDB
        </Typography>

        {!showForm && (
          <>
            {successMessage && (
              <Alert severity="success">{successMessage}</Alert>
            )}
            {serverError && <Alert severity="error">{serverError}</Alert>}

            <Button variant="contained" onClick={handleAddNew} sx={{ mb: 2 }}>
              Add New Student to MongoDB
            </Button>

            <StudentTable
              students={students}
              handleEdit={handleEdit}
              handleDelete={handleDelete}
            />
          </>
        )}

        {showForm && (
          <Box mt={3} p={3} boxShadow={3}>
            <Typography variant="h6" mb={2}>
              {editingId ? "Edit Student" : "Add Student"}
            </Typography>

            

            <form onSubmit={handleSubmit} noValidate>
              <TextField
                fullWidth
                label="Name"
                name="name"
                value={form.name}
                onChange={handleChange}
                margin="normal"
                error={!!errors.name}
                helperText={errors.name}
              />
              <TextField
                fullWidth
                label="Email"
                name="email"
                value={form.email}
                onChange={handleChange}
                margin="normal"
                error={!!errors.email}
                helperText={errors.email}
              />
              <TextField
                fullWidth
                label="Age"
                name="age"
                value={form.age}
                onChange={handleChange}
                margin="normal"
                error={!!errors.age}
                helperText={errors.age}
              />
              <TextField
                fullWidth
                label="Course"
                name="course"
                value={form.course}
                onChange={handleChange}
                margin="normal"
                error={!!errors.course}
                helperText={errors.course}
              />

              <Box display="flex" justifyContent="space-between" mt={2}>
                <Button type="submit" variant="contained" color="primary">
                  {editingId ? "Update" : "Save"}
                </Button>
                <Button variant="outlined" onClick={() => setShowForm(false)}>
                  Cancel
                </Button>
              </Box>
            </form>
          </Box>
        )}
      </Box>
    </Container>
  );
};

export default StudentCRUD;
