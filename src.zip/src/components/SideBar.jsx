import { Link } from "react-router-dom";
export default function SideBar() {
  return (
    <div style={{ width: "300px", padding: "10px", background: "#f0f0f0", height: "100vh" }}>
      <h3>MainMenu</h3>
      <ul style={{ listStyle: "none", paddingLeft: 0 }}>
        <li><Link to="/student">Students</Link></li>
        <li><Link to="/login">Login</Link></li>
        <li><Link to="/register">Register</Link></li>
        <li><Link to="/logout">Logout</Link></li>
      </ul>
    </div>
  );
}