import { useNavigate, Link as RouterLink } from "react-router-dom";
import { useState } from "react";
import axios from "axios";
import {
  TextField,
  Button,
  Box,
  Typography,
  Alert,
  Link,
} from "@mui/material";

export default function RegisterPage({ setIsAuthenticated }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();

  const handleRegister = async () => {
     
     try {
      const response = await axios.post("http://localhost:5000/api/auth/register", { email, password });
      localStorage.setItem("user", response.data.email);
      setIsAuthenticated(true);
      navigate("/student");
    } catch (err) {
      const message =
        err.response?.data?.message || err.message || "Registration failed";
      setError(message);
    } 
  };

  return (
    <Box
      sx={{
        height: "100vh",
        display: "flex",
        width: "100vw",
        justifyContent: "center",
        alignItems: "center",
        bgcolor: "#f5f5f5",
        px: 2,
      }}
    >
      <Box
        sx={{
          width: "100%",
          maxWidth: 400,
          p: 4,
          boxShadow: 3,
          borderRadius: 2,
          bgcolor: "background.paper",
          textAlign: "center",
        }}
      >
        <Typography variant="h4" mb={3}>
          Register
        </Typography>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}

        <TextField
          label="Email/RollNo"
          variant="outlined"
          fullWidth
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          margin="normal"
          type="email"
          disabled={loading}
        />

        <TextField
          label="Password"
          variant="outlined"
          fullWidth
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          margin="normal"
          type="password"
          disabled={loading}
        />

        <Button
          type="button"
          variant="contained"
          color="primary"
          fullWidth
          onClick={handleRegister}
          disabled={!email || !password || loading}
          sx={{ mt: 2, mb: 1 }}
        >
          Register
        </Button>

        <Typography variant="body2">
          Already have an account?{" "}
          <Link component={RouterLink} to="/login">
            Login here
          </Link>
        </Typography>
      </Box>
    </Box>
  );
}
