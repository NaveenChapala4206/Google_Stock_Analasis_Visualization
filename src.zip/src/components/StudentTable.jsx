import * as React from "react";
import { Box, Button } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";

const StudentTable = ({ students, handleEdit, handleDelete }) => {
  const columns = [
    { field: "sno", headerName: "SNo", width: 150 },
    { field: "name", headerName: "Name", width: 150 },
    { field: "email", headerName: "Email", width: 200 },
    { field: "age", headerName: "Age", width: 100, type: "number" },
    { field: "course", headerName: "Course", width: 150 },
    {
      field: "actions",
      headerName: "Actions",
      width: 200,
      sortable: false,
      renderCell: (params) => (
        <Box>
          <Button
            onClick={() => handleEdit(params.row)}
            size="small"
            style={{ marginRight: 8 }}
          >
            Edit
          </Button>
          <Button
            onClick={() => handleDelete(params.row._id || params.row.id)}
            size="small"
            color="error"
          >
            Delete
          </Button>
        </Box>
      ),
    },
  ];

  const rows = students.map((s, i) => ({
    sno: i+1,
    id: s._id,
    ...s,
  }));

  return (
    <Box sx={{ width: "100%", overflowX: "auto" }}>
      <Box sx={{ minWidth: 800, height: 500 }}>
        <DataGrid
          rows={rows}
          columns={columns}
          pageSize={5}
          rowsPerPageOptions={[5, 10, 25, 50]}
          pagination
        />
      </Box>
    </Box>
  );
};

export default StudentTable;
